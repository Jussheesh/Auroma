// Auroma - Full Site Logic

var cart = [];

// ===== PAGE NAVIGATION =====
function showPage(pageName) {
    var pages = document.querySelectorAll('.page');
    for (var i = 0; i < pages.length; i++) {
        pages[i].classList.remove('active');
    }
    var target = document.getElementById(pageName + '-page');
    if (target) target.classList.add('active');

    // Update nav active state
    var navLinks = document.querySelectorAll('.nav-link');
    for (var j = 0; j < navLinks.length; j++) {
        navLinks[j].classList.remove('active');
        if (navLinks[j].getAttribute('data-page') === pageName) {
            navLinks[j].classList.add('active');
        }
    }

    // Show/hide header on signin page
    var header = document.getElementById('main-header');
    if (header) {
        header.style.display = (pageName === 'signin') ? 'none' : 'flex';
    }

    window.scrollTo(0, 0);
}

// ===== CART FUNCTIONS =====
function updateCartBadge() {
    var badge = document.getElementById('cart-badge');
    var total = 0;
    for (var i = 0; i < cart.length; i++) total += cart[i].qty;
    if (badge) badge.textContent = total;
}

function addToCart(name, price, img) {
    for (var i = 0; i < cart.length; i++) {
        if (cart[i].name === name) {
            cart[i].qty++;
            updateCartBadge();
            renderCart();
            return;
        }
    }
    cart.push({ name: name, price: parseFloat(price), img: img, qty: 1 });
    updateCartBadge();
    renderCart();
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartBadge();
    renderCart();
}

function changeQty(index, delta) {
    cart[index].qty += delta;
    if (cart[index].qty <= 0) {
        cart.splice(index, 1);
    }
    updateCartBadge();
    renderCart();
}

function renderCart() {
    var container = document.getElementById('cart-items');
    var itemsCount = document.getElementById('summary-items-count');
    var totalEl = document.getElementById('summary-total');
    if (!container) return;

    if (cart.length === 0) {
        container.innerHTML = '<p class="cart-empty" id="cart-empty-text">Your cart is empty</p>';
        if (itemsCount) itemsCount.textContent = '0';
        if (totalEl) totalEl.textContent = '$0.00';
        return;
    }

    var html = '';
    var total = 0;
    var totalItems = 0;
    for (var i = 0; i < cart.length; i++) {
        var item = cart[i];
        var subtotal = item.price * item.qty;
        total += subtotal;
        totalItems += item.qty;
        html += '<div class="cart-item">';
        html += '<div class="cart-item-img"><img src="' + item.img + '" alt="' + item.name + '"></div>';
        html += '<div class="cart-item-details">';
        html += '<div class="cart-item-name">' + item.name + '</div>';
        html += '<div class="cart-item-price">$' + item.price.toFixed(2) + '</div>';
        html += '<div class="qty-controls">';
        html += '<button class="qty-btn" onclick="changeQty(' + i + ', -1)">−</button>';
        html += '<span class="qty-value">' + item.qty + '</span>';
        html += '<button class="qty-btn" onclick="changeQty(' + i + ', 1)">+</button>';
        html += '</div></div>';
        html += '<button class="cart-item-remove" onclick="removeFromCart(' + i + ')">✕</button>';
        html += '</div>';
    }
    container.innerHTML = html;
    if (itemsCount) itemsCount.textContent = totalItems;
    if (totalEl) totalEl.textContent = '$' + total.toFixed(2);
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', function () {

    // Navigation links with data-page
    var pageLinks = document.querySelectorAll('[data-page]');
    for (var i = 0; i < pageLinks.length; i++) {
        pageLinks[i].addEventListener('click', function (e) {
            e.preventDefault();
            var pageName = this.getAttribute('data-page');
            showPage(pageName);
        });
    }

    // Add to cart buttons
    var addBtns = document.querySelectorAll('.add-to-cart-btn');
    for (var j = 0; j < addBtns.length; j++) {
        addBtns[j].addEventListener('click', function () {
            var name = this.getAttribute('data-name');
            var price = this.getAttribute('data-price');
            var img = this.getAttribute('data-img');
            addToCart(name, price, img);
            // Brief visual feedback
            this.textContent = 'Added ✓';
            this.style.background = '#2F2FE4';
            var btn = this;
            setTimeout(function () {
                btn.textContent = 'Add to Cart';
                btn.style.background = 'transparent';
            }, 1200);
        });
    }

    // Checkout
    var checkoutBtn = document.getElementById('checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function () {
            if (cart.length === 0) {
                alert('Your cart is empty!');
                return;
            }
            alert('Thank you for your order! Total: $' + cart.reduce(function(s,c){ return s + c.price * c.qty; }, 0).toFixed(2));
            cart = [];
            updateCartBadge();
            renderCart();
            showPage('home');
        });
    }

    // Sign-in form
    var signinForm = document.getElementById('signin-form');
    if (signinForm) {
        signinForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var email = document.getElementById('email-input').value.trim();
            var pass = document.getElementById('password-input').value.trim();
            if (!email || !pass) { alert('Please fill in all fields.'); return; }
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) { alert('Please enter a valid email.'); return; }
            alert('Welcome to Auroma! Signed in as: ' + email);
            showPage('home');
        });
    }

    // Sign up / Sign in toggle
    var switchLink = document.getElementById('switch-to-signup');
    if (switchLink) {
        var isSignUp = false;
        switchLink.addEventListener('click', function (e) {
            e.preventDefault();
            isSignUp = !isSignUp;
            var title = document.getElementById('signin-title');
            var subtitle = document.getElementById('signin-subtitle');
            var btn = document.getElementById('continue-btn');
            var switchText = document.getElementById('signin-switch');
            if (isSignUp) {
                title.textContent = 'Sign up';
                subtitle.textContent = 'Create a new account';
                btn.textContent = 'Create Account';
                switchText.innerHTML = 'Already have an account? <a href="javascript:void(0)" class="switch-link" id="switch-to-signup">Sign in</a>';
            } else {
                title.textContent = 'Sign in';
                subtitle.textContent = 'Sign up or create an account';
                btn.textContent = 'Continue';
                switchText.innerHTML = 'Don\'t have an account? <a href="javascript:void(0)" class="switch-link" id="switch-to-signup">Sign up</a>';
            }
            // Re-bind click
            document.getElementById('switch-to-signup').addEventListener('click', arguments.callee);
        });
    }

    updateCartBadge();
});
